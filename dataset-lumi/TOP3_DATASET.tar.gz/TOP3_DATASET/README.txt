TGV STORE NONE TOP 3 — COMPLETE PORTABLE SHARED DATASET, VERSION 2

All 12 node sections (2,3,4,6,8,10,12,16,20,24,32,40), 48 roles and 45 unique
runtime catalogs are complete. Each catalog has one blocks.csv shared by all
MPI ranks. Columns: kernel_id,bx,by,bz. No autotuning is required.

The selected grids/MPI Top 3 and source tuning repetitions are unchanged.
For 6–40 nodes the historical shared catalog bytes are unchanged.
For 2–4 nodes the historical per-rank exports are incomplete. A new shared
catalog is derived from the retained rank 0/1 best logs of the same selected
repetition, using the original OPS_APP_lumi_original_tuning shared_blocks
policy: majority block, then lowest measured best_time, then block tuple.
Every chosen block is an observed best block. No missing rank measurements
are fabricated. Historical per-rank manifests and source logs are preserved;
historical_missing_blocks.csv records the old gaps, not runtime requirements.
These derived shared catalogs require NEW timing measurements; do not assign
historical timings to them. This is a transfer experiment, not exact replay.

All 25 tuned kernels (2–26) have blocks. Initialization kernel 1 keeps the
existing OPS default fallback; it has no tuned best entry in the originals.
block_provenance.csv traces all 1125 block selections to source rank/log/time.
coverage.csv and nNNN/cases.csv describe the executable runtime inputs.
source_campaigns/ contains original measured logs/configs without edits.
Original absolute paths are provenance; runtime catalog paths are relative.

Validate all files/catalogs/provenance (Python 3.6+):
  python3 prepare_dataset.py --validate-only --dataset /path/to/TOP3_DATASET
Rebuild from a verified source package, in a new directory:
  python3 prepare_dataset.py --source-package /path/to/source_package \
    --output-root /path/to/new/TOP3_DATASET

Local validation covers package/runtime input compatibility. The newly built
HIP executable, MPI and GPU Direct still require the launcher smoke on LUMI.
