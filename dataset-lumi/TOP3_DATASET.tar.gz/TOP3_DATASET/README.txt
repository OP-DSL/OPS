TGV STORE NONE — PORTABLE TOP 3 DATASET

12 node sections; 8 MPI ranks per node; 500 simulation steps.
Selection: selections.csv (frozen original Top 3 table).
C = recorded default/reference MPI + precomputed.
D_top1/2/3 = selected MPI configurations + their original precomputed.
Ranking uses kernel time; no retuning or new measurements were performed.

LAYOUT
nNNN/cases.csv: four roles, with paths relative to this package root.
nNNN/precomputed_blocks/<app_grid_cfg>/mode_1/decomp<shape>/:
  original manifest.json and blocks.csv (shared schema 2), or
  rank_N/blocks.csv (per-rank schema 1).
nNNN/source_campaigns/: original tuning config, MPI metrics, run log,
  best/tuning logs for required ranks where available; measured C/D configs.
coverage.csv: completeness per unique catalog, source logs and validation.
missing_blocks.csv: missing file names, original LUMI paths and SHA256.

RUNTIME INPUT
blocks.csv has exactly kernel_id,bx,by,bz. Preserve rank scope.
The original manifests and raw logs are unchanged. Historical absolute paths
are provenance only; locate files via cases.csv and relative catalog paths.
Do not replay INCOMPLETE catalogs or fill missing ranks with rank 0 blocks.
Absent kernel entries in an existing CSV retain OPS runtime default fallback.
Readiness of a catalog does not establish compatibility with a newly built
executable. Original OPS validation checks the executable SHA256/context;
validate kernel identity and target compatibility before a new LUMI run.
The original selections.csv paths are also provenance, not portable inputs.

VALIDATE AFTER COPYING THE PACKAGE (Python >=3.9)
python3 prepare_dataset.py --validate-only
The validator uses only packaged files and tools/ops_precomputed.py, copied
unchanged from OPS_APP_lumi_original_tuning/ops_launcher/precomputed.py.
Validation can pass integrity while reporting incomplete catalogs.

REBUILD FROM ORIGINAL SOURCES
python3 prepare_dataset.py --source-csv /path/to/top3.csv \
  --source-root /path/to/lumi-dataset --output-root /path/to/new_package
Use --inventory-only to inspect sources without copying data.
Existing differing source copies are never silently overwritten.
