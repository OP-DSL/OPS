#!/usr/bin/env python3
"""Build/validate a portable, provenance-preserving OPS TGV-SN replay dataset."""
import argparse
import csv
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import tempfile
from datetime import datetime, timezone
import hashlib

HERE = Path(__file__).resolve().parent
NODES = (2, 3, 4, 6, 8, 10, 12, 16, 20, 24, 32, 40)
LOG_NAMES = ('ops_blocksize_best_logmod.csv', 'ops_blocksize_tuning_logmod.csv')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read_fields(path):
    return dict(line.split('=', 1) for line in path.read_text().splitlines() if '=' in line)


def read_csv(path):
    with path.open(newline='') as f:
        return list(csv.DictReader(f))


def json_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    temp.replace(path)


def csv_write(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def load_helper(path):
    spec = importlib.util.spec_from_file_location('ops_catalog_helper', path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    return helper


def dimensions(value):
    return tuple(map(int, re.split('[x×]', value)))


def plan(args, helper):
    rows = read_csv(args.source_csv)
    require(len(rows) == 36, 'Expected 36 Top 3 rows')
    cases, catalogs = [], {}
    for nodes in NODES:
        selected = sorted((r for r in rows if int(r['Nodes']) == nodes), key=lambda r: int(r['Top rank']))
        require([r['Top rank'] for r in selected] == ['1', '2', '3'], f'Invalid Top 3 for {nodes}')
        for field in ('Campaign', 'Config.', 'Global grid', 'Fixed baseline MPI decomposition', 'Executable SHA256', 'Simulation iterations'):
            require(len({r[field] for r in selected}) == 1, f'Mixed context: {nodes} {field}')
        for side, role, row in [('C', 'C', selected[0])] + [('D', 'D_top' + r['Top rank'], r) for r in selected]:
            grid = dimensions(row['Global grid'])
            shape = dimensions(row['Fixed baseline MPI decomposition' if side == 'C' else 'Tested MPI decomposition'])
            require(len(grid) == len(shape) == 3 and len(set(grid)) == 1, 'Invalid cube/shape')
            require(math.prod(shape) == nodes * 8 and all(g % p == 0 for g, p in zip(grid, shape)), 'Invalid decomposition')
            require(row['Simulation iterations'] == '500', 'Unexpected simulation iterations')
            configs = []
            for raw in row[f'{side} source configs'].replace('\\n', '\n').splitlines():
                parts = Path(raw).parts
                i = parts.index(row['Campaign'])
                configs.append(args.source_root.joinpath(*parts[i:]))
            reference = None
            folders, manifests = [], []
            originals = set()
            for config in configs:
                require(config.is_file(), f'Missing source config: {config}')
                meta = read_fields(config)
                require(meta['OPS_AUTOTUNE_MODE'] == '2' and meta['APP_NAME'] == 'tgvstorenone', f'Wrong source: {config}')
                originals.add(meta['PRECOMPUTED_CATALOG'])
                catalog = args.source_root / row['Campaign'] / 'precomputed_blocks' / meta['PRECOMPUTED_CATALOG'].split('/precomputed_blocks/', 1)[1]
                for folder, mp in ((catalog, catalog / 'manifest.json'), (config.parent, config.parent / 'precomputed_manifest.json')):
                    if not mp.is_file():
                        continue
                    m = json.loads(mp.read_text())
                    require(m['set_id'] == meta['PRECOMPUTED_SET_ID'], f'Wrong set ID: {mp}')
                    unsigned = dict(m)
                    sid = unsigned.pop('set_id')
                    require(sid == helper.digest(json.dumps(unsigned, sort_keys=True).encode()), f'Changed manifest: {mp}')
                    if reference is None:
                        reference = m
                    require(m == reference, f'Repetitions/manifests disagree: {mp}')
                    if folder not in folders:
                        folders.append(folder)
                        manifests.append(mp)
            require(reference is not None, 'No source manifest')
            ctx = reference['context']
            expected_ctx = dict(APP_NAME='tgvstorenone', GRID_CONFIG=row['Config.'],
                                GRID_X=str(grid[0]), GRID_Y=str(grid[1]), GRID_Z=str(grid[2]),
                                DECOMPOSITION_MODE='1', ACTIVE_NUM_RANKS=str(nodes * 8),
                                shape='x'.join(map(str, shape)), APP_ARGS=' '.join(map(str, grid)) + ' 500',
                                GPU_ARCH='gfx90a', EXECUTABLE_SHA256=row['Executable SHA256'])
            require(all(ctx.get(k) == v for k, v in expected_ctx.items()), f'Incompatible context: {nodes} {role}')
            schema = reference['schema_version']
            require(schema in (1, 2), 'Unknown schema')
            expected = {'blocks.csv'} if schema == 2 else {f'rank_{i}/blocks.csv' for i in range(nodes * 8)}
            require(set(reference['files']) == expected, 'Manifest does not cover expected ranks')
            parts = Path(reference['source_run']).parts
            i = next(i for i, x in enumerate(parts) if x.startswith('OPS_LOGS_'))
            run_rel = Path(row['Campaign']).joinpath(*parts[i+1:])
            run = args.source_root / run_rel
            relative = Path(f'n{nodes:03d}') / 'precomputed_blocks' / helper.case_path(ctx)
            catalog_id = str(relative)
            case = dict(nodes=nodes, role=role, top_rank='' if side == 'C' else row['Top rank'],
                        application='tgvstorenone', global_grid='x'.join(map(str, grid)),
                        mpi_decomposition=ctx['shape'], mpi_ranks=nodes * 8, simulation_iterations=500,
                        catalog_path=catalog_id, set_id=reference['set_id'], schema_version=schema,
                        source_campaign=row['Campaign'], historical_executable_sha256=ctx['EXECUTABLE_SHA256'])
            cases.append(case)
            if catalog_id in catalogs:
                require(catalogs[catalog_id]['manifest'] == reference, 'Conflicting duplicate catalog')
                catalogs[catalog_id]['roles'].append(role)
                continue
            files, missing, recovered = {}, [], {}
            for name, checksum in reference['files'].items():
                found = [folder / name for folder in folders if (folder / name).is_file()]
                for path in found:
                    require(sha(path) == checksum, f'Checksum mismatch: {path}')
                    require(helper.normalize_blocks(path) == path.read_bytes(), f'Not normalized: {path}')
                if found:
                    files[name] = found[0]
                elif schema == 1:
                    raw = run / Path(name).parent / 'autotune_on' / LOG_NAMES[0]
                    if raw.is_file():
                        data = helper.normalize_blocks(raw)
                        require(helper.digest(data) == checksum, f'Recovered block differs from original: {raw}')
                        recovered[name] = (raw, data)
                    else:
                        missing.append(name)
                else:
                    missing.append(name)
            sample_ranks = list(map(int, ctx.get('AUTOTUNE_SAMPLE_RANKS', '').split())) if schema == 2 else list(range(nodes * 8))
            require(sample_ranks and all(0 <= r < nodes * 8 for r in sample_ranks), 'Invalid sample ranks')
            logs = []
            log_missing = []
            for name in ('config.txt', 'mpi_rank_metrics.csv'):
                if (run / name).is_file():
                    logs.append(run / name)
                else:
                    log_missing.append(name)
            if (run / 'run.log').is_file():
                logs.append(run / 'run.log')
            best = {}
            for rank in sample_ranks:
                for name in LOG_NAMES:
                    path = run / f'rank_{rank}' / 'autotune_on' / name
                    if path.is_file():
                        logs.append(path)
                        if name == LOG_NAMES[0]:
                            best[rank] = path
                    else:
                        log_missing.append(str(path.relative_to(run)))
            if (run / 'config.txt').is_file():
                meta = read_fields(run / 'config.txt')
                require(meta['OPS_AUTOTUNE_MODE'] == '1' and int(meta['RUN_ITERATION']) == reference['repetition'], 'Wrong tuning origin')
                for k in ('APP_NAME', 'GRID_X', 'GRID_Y', 'GRID_Z', 'APP_ARGS', 'GPU_ARCH', 'EXECUTABLE_SHA256'):
                    require(meta[k] == ctx[k], f'Tuning context mismatch: {k}')
            verification = 'PARTIAL'
            if schema == 2 and set(best) == set(sample_ranks):
                rebuilt, _ = helper.shared_blocks(best)
                require(helper.digest(rebuilt) == reference['files']['blocks.csv'], f'Shared consensus differs: {run}')
                verification = 'MATCH'
                if 'blocks.csv' in missing:
                    recovered['blocks.csv'] = (run, rebuilt)
                    missing.remove('blocks.csv')
            elif schema == 1:
                for rank, path in best.items():
                    require(helper.digest(helper.normalize_blocks(path)) == reference['files'][f'rank_{rank}/blocks.csv'], f'Best log differs: {path}')
                if len(best) == nodes * 8:
                    verification = 'MATCH'
            catalogs[catalog_id] = dict(nodes=nodes, roles=[role], manifest=reference,
                manifest_source=manifests[0], files=files, missing=missing, recovered=recovered,
                run=run, run_rel=run_rel, logs=logs, log_missing=log_missing,
                verification=verification, originals=sorted(originals), configs=configs)
    require(len(cases) == 48, 'Expected 48 roles')
    return cases, catalogs


def validate(root, helper):
    manifest = json.loads((root / 'dataset_manifest.json').read_text())
    for rel, entry in manifest['files'].items():
        path = root / rel
        require(path.resolve().is_relative_to(root.resolve()), f'External file: {rel}')
        require(path.is_file() and not path.is_symlink() and sha(path) == entry['sha256'], f'Invalid packaged file: {rel}')
    cases = []
    for nodes in NODES:
        local = read_csv(root / f'n{nodes:03d}/cases.csv')
        require({r['role'] for r in local} == {'C', 'D_top1', 'D_top2', 'D_top3'}, 'Missing roles')
        cases.extend(local)
    coverage = read_csv(root / 'coverage.csv')
    for item in coverage:
        folder = root / item['catalog_path']
        m = json.loads((folder / 'manifest.json').read_text())
        available = [name for name in m['files'] if (folder / name).is_file()]
        require(len(available) == int(item['block_files_available']), 'Coverage mismatch')
        require(len(m['files']) - len(available) == int(item['block_files_missing']), 'Missing count mismatch')
        if item['catalog_status'] == 'COMPLETE':
            helper.validate_catalog(folder, m['context'])
        for case in (c for c in cases if c['catalog_path'] == item['catalog_path']):
            require(case['set_id'] == m['set_id'] and case['catalog_status'] == item['catalog_status'], 'Case mismatch')
    print(json.dumps(manifest['summary'], indent=2), flush=True)
    print('PASS: packaged files, role mappings and complete OPS catalogs validated using only relative package paths.', flush=True)
    return manifest


def build(args, helper, cases, catalogs):
    root = args.output_root
    root.mkdir(parents=True, exist_ok=True)
    registry = {}
    def copy(source, relative):
        source = Path(source)
        dest = root / relative
        checksum = sha(source)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            require(sha(dest) == checksum, f'Refusing to overwrite different file: {dest}')
        else:
            fd, name = tempfile.mkstemp(prefix='.copy-', dir=dest.parent)
            os.close(fd)
            try:
                shutil.copyfile(source, name)
                require(sha(name) == checksum, f'Copy checksum mismatch: {source}')
                Path(name).replace(dest)
            finally:
                if Path(name).exists():
                    Path(name).unlink()
        registry[str(relative)] = dict(sha256=checksum, bytes=dest.stat().st_size, source=str(source))
    copy(args.source_csv, Path('selections.csv'))
    copy(args.helper, Path('tools/ops_precomputed.py'))
    if Path(__file__).resolve() != root / 'prepare_dataset.py':
        copy(Path(__file__).resolve(), Path('prepare_dataset.py'))
    coverage, missing_rows = [], []
    for rel, cat in catalogs.items():
        m = cat['manifest']
        copy(cat['manifest_source'], Path(rel) / 'manifest.json')
        for name, source in cat['files'].items():
            copy(source, Path(rel) / name)
        for name, (source, data) in cat['recovered'].items():
            dest = root / rel / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                require(dest.read_bytes() == data, 'Recovery overwrite conflict')
            else:
                dest.write_bytes(data)
            registry[str(dest.relative_to(root))] = dict(sha256=sha(dest), bytes=len(data), source=str(source), recovery='normalized original best log; exact original checksum')
        source_rel = Path(f"n{cat['nodes']:03d}") / 'source_campaigns' / cat['run_rel']
        for source in cat['logs']:
            copy(source, source_rel / source.relative_to(cat['run']))
        # Preserve the measured precomputed config/manifest links for all three repetitions.
        for config in cat['configs']:
            dest = Path(f"n{cat['nodes']:03d}") / 'source_campaigns' / config.relative_to(args.source_root)
            copy(config, dest)
            mp = config.parent / 'precomputed_manifest.json'
            if mp.is_file():
                copy(mp, dest.parent / mp.name)
        status = 'INCOMPLETE' if cat['missing'] else 'COMPLETE'
        logs_status = 'COMPLETE' if not cat['log_missing'] else ('PARTIAL' if cat['logs'] else 'MISSING')
        item = dict(nodes=cat['nodes'], roles=','.join(cat['roles']), catalog_path=rel, set_id=m['set_id'],
                    schema_version=m['schema_version'], catalog_status=status,
                    block_files_expected=len(m['files']), block_files_available=len(cat['files']) + len(cat['recovered']),
                    block_files_missing=len(cat['missing']), recovered_files=len(cat['recovered']),
                    source_logs_status=logs_status, original_best_verification=cat['verification'],
                    source_run_path=str(source_rel), missing_source_files='\n'.join(cat['log_missing']),
                    portable_paths_status='PASS', target_executable_status='NOT_VALIDATED')
        coverage.append(item)
        for case in cases:
            if case['catalog_path'] == rel:
                case.update(catalog_status=status, source_logs_status=logs_status,
                            source_run_path=str(source_rel), target_executable_status='NOT_VALIDATED')
        for name in cat['missing']:
            missing_rows.append(dict(nodes=cat['nodes'], roles=','.join(cat['roles']), catalog_path=rel,
                                     relative_file=name, expected_sha256=m['files'][name],
                                     original_lumi_paths='\n'.join(str(Path(p) / name) for p in cat['originals'])))
        print(f"n{cat['nodes']:03d} {m['context']['shape']}: {status}; logs {logs_status}", flush=True)
    for nodes in NODES:
        csv_write(root / f'n{nodes:03d}/cases.csv', [c for c in cases if c['nodes'] == nodes])
    csv_write(root / 'coverage.csv', coverage)
    csv_write(root / 'missing_blocks.csv', missing_rows,
              ['nodes', 'roles', 'catalog_path', 'relative_file', 'expected_sha256', 'original_lumi_paths'])
    summary = dict(node_sections=12, selected_top3_rows=36, roles=len(cases), unique_catalogs=len(catalogs),
                   complete_catalogs=sum(c['catalog_status'] == 'COMPLETE' for c in coverage),
                   incomplete_catalogs=sum(c['catalog_status'] == 'INCOMPLETE' for c in coverage),
                   missing_block_files=len(missing_rows), recovered_block_files=sum(c['recovered_files'] for c in coverage),
                   complete_source_logs=sum(c['source_logs_status'] == 'COMPLETE' for c in coverage),
                   full_campaign_ready=not missing_rows, target_executable_status='NOT_VALIDATED')
    (root / 'README.txt').write_text('''TGV STORE NONE — PORTABLE TOP 3 DATASET

12 node sections; 8 MPI ranks per node; 500 simulation steps.
Selection: selections.csv (frozen original Top 3 table).
C = recorded default/reference MPI + precomputed.
D_top1/2/3 = selected MPI configurations + their original precomputed.
Ranking uses kernel time; no retuning or new measurements were performed.

LAYOUT
nNNN/cases.csv: four roles, with paths relative to this package root.
nNNN/precomputed_blocks/<app_grid_cfg>/mode_1/decomp<shape>/:
  original manifest.json and blocks.csv (shared schema 2), or
  rank_N/blocks.csv (per-rank schema 1).
nNNN/source_campaigns/: original tuning config, MPI metrics, run log,
  best/tuning logs for required ranks where available; measured C/D configs.
coverage.csv: completeness per unique catalog, source logs and validation.
missing_blocks.csv: missing file names, original LUMI paths and SHA256.

RUNTIME INPUT
blocks.csv has exactly kernel_id,bx,by,bz. Preserve rank scope.
The original manifests and raw logs are unchanged. Historical absolute paths
are provenance only; locate files via cases.csv and relative catalog paths.
Do not replay INCOMPLETE catalogs or fill missing ranks with rank 0 blocks.
Absent kernel entries in an existing CSV retain OPS runtime default fallback.
Readiness of a catalog does not establish compatibility with a newly built
executable. Original OPS validation checks the executable SHA256/context;
validate kernel identity and target compatibility before a new LUMI run.
The original selections.csv paths are also provenance, not portable inputs.

VALIDATE AFTER COPYING THE PACKAGE (Python >=3.9)
python3 prepare_dataset.py --validate-only
The validator uses only packaged files and tools/ops_precomputed.py, copied
unchanged from OPS_APP_lumi_original_tuning/ops_launcher/precomputed.py.
Validation can pass integrity while reporting incomplete catalogs.

REBUILD FROM ORIGINAL SOURCES
python3 prepare_dataset.py --source-csv /path/to/top3.csv \\
  --source-root /path/to/lumi-dataset --output-root /path/to/new_package
Use --inventory-only to inspect sources without copying data.
Existing differing source copies are never silently overwritten.
''')
    for path in [root / 'README.txt', root / 'coverage.csv', root / 'missing_blocks.csv',
                 root / 'prepare_dataset.py'] + [root / f'n{n:03d}/cases.csv' for n in NODES]:
        registry[str(path.relative_to(root))] = dict(sha256=sha(path), bytes=path.stat().st_size, source='generated')
    json_write(root / 'dataset_manifest.json', dict(schema_version=1, application='tgvstorenone',
        created_utc=datetime.now(timezone.utc).isoformat(), summary=summary,
        selection_sha256=sha(args.source_csv), preparation_source_root=str(args.source_root),
        validator_origin=str(args.helper), files=registry))
    validate(root, helper)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-csv', type=Path, default=HERE.parent / 'top3/tgvstorenone_top3_kernel_comparisons.csv')
    parser.add_argument('--source-root', type=Path, default=HERE.parent.parent)
    parser.add_argument('--output-root', type=Path, default=HERE)
    parser.add_argument('--helper', type=Path, default=HERE / 'tools/ops_precomputed.py')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--validate-only', action='store_true')
    mode.add_argument('--inventory-only', action='store_true')
    args = parser.parse_args()
    for name in ('source_csv', 'source_root', 'output_root', 'helper'):
        setattr(args, name, getattr(args, name).resolve())
    helper = load_helper(args.helper)
    if args.validate_only:
        validate(args.output_root, helper)
        return
    cases, catalogs = plan(args, helper)
    if args.inventory_only:
        print(json.dumps(dict(roles=len(cases), catalogs=len(catalogs),
            missing_blocks=sum(len(c['missing']) for c in catalogs.values()),
            source_log_bytes=sum(p.stat().st_size for c in catalogs.values() for p in c['logs'])), indent=2))
        return
    build(args, helper, cases, catalogs)


if __name__ == '__main__':
    main()
