"""Standalone catalog helper, embedded in generated decomposition campaigns.

OPS mode 2 reads kernel_id,bx,by,bz from the first four CSV columns.
Legacy catalogs freeze one file per MPI rank.  Sampled catalogs freeze one
shared blocks.csv selected from a small set of representative ranks.
"""
import csv
import hashlib
import io
import json
import math
import os
import re
from pathlib import Path
import shutil
import stat
import sys
import tempfile


EXECUTOR_VERSION = 2


def result_complete(run, record=None):
    """The single acceptance predicate for new campaign results (read-only)."""
    run = Path(run)
    try:
        fields = metadata(run / 'config.txt')
        if tuple(fields.get(k) for k in ('RUN_STATUS', 'RUN_EXIT_CODE',
                                        'VALIDATION_STATUS', 'COMMIT_STATUS')) != (
                                            'OK', '0', 'PASS', 'COMMITTED'):
            return False
        for key in ('APP_WALL_TIME', 'JOB_WALL_TIME'):
            value = float(fields[key])
            if not math.isfinite(value) or value <= 0:
                return False
        if not re.fullmatch('[0-9a-f]{64}', fields['EXECUTABLE_SHA256']):
            return False
        expected = int(fields['NUM_MPI_RANKS'])
        if expected < 1:
            return False
        if record:
            mapping = {'CASE_ID': 'case_id', 'APP_NAME': 'app', 'APP_ARGS': 'app_args',
                       'NUM_MPI_RANKS': 'ranks', 'NUM_NODES': 'nodes',
                       'RUN_ITERATION': 'repetition', 'OPS_AUTOTUNE_MODE': 'autotune_mode',
                       'DECOMPOSITION_MODE': 'decomposition_mode', 'GRID_CONFIG': 'grid_config'}
            if any(fields.get(k) != str(record[v]) for k, v in mapping.items()):
                return False
            if [int(fields['GRID_' + a]) for a in 'XYZ'] != record['grid']:
                return False
            if [int(fields['DECOMP_P' + a]) for a in 'XYZ'] != record['decomposition']:
                return False
        with (run / 'mpi_rank_metrics.csv').open() as handle:
            rows = list(csv.DictReader(handle))
        if (len(rows) != expected or {r['rank_id'] for r in rows} != {str(i) for i in range(expected)}
                or any(r['rank_status'] != 'OK' for r in rows)):
            return False
        for row in rows:
            value = float(row['rank_wall_time_s'])
            if not math.isfinite(value) or value <= 0:
                return False
            if not (run / 'ranks' / ('rank_' + row['rank_id'] + '.log')).is_file():
                return False
        if fields.get('OPS_AUTOTUNE_MODE') == '2':
            manifest = json.loads((run / 'precomputed_manifest.json').read_text())
            ctx = manifest['context']
            keys = ('APP_NAME', 'GRID_X', 'GRID_Y', 'GRID_Z', 'GRID_CONFIG',
                    'DECOMPOSITION_MODE', 'APP_ARGS', 'GPU_ARCH', 'EXECUTABLE_SHA256')
            if (any(ctx[k] != fields[k] for k in keys)
                    or ctx['ACTIVE_NUM_RANKS'] != str(expected)
                    or ctx['shape'] != 'x'.join(fields['DECOMP_P' + a] for a in 'XYZ')):
                return False
            validate_catalog(run, ctx, manifest_name='precomputed_manifest.json')
        return True
    except (OSError, ValueError, KeyError, TypeError):
        return False


def campaign_progress(root, app=None):
    root = Path(root)
    records = [json.loads(line) for line in (root / 'plan.jsonl').read_text().splitlines() if line.strip()]
    manifest = root / 'campaign_manifest.json'
    if manifest.exists() and json.loads(manifest.read_text())['plan_sha256'] != digest((root / 'plan.jsonl').read_bytes()):
        raise ValueError('Campaign plan checksum mismatch')
    records = [r for r in records if app is None or r['app'] == app]
    return sum(result_complete(root / r['target'], r) for r in records), len(records)


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, delete=False) as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    temporary.replace(path)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def metadata(path):
    return dict(line.split('=', 1) for line in path.read_text().splitlines() if '=' in line)


def executable_digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            checksum.update(chunk)
    return checksum.hexdigest()


def recorded_executable_sha256(root, app):
    """Return the executable identity required by completed tuning results."""
    recorded = set()
    identity = root / '_decomposition_executables' / app / 'identity.json'
    if identity.is_file():
        recorded.add(json.loads(identity.read_text())['sha256'])
    for path in (root / 'precomputed_blocks').glob(app + '_hip_*/mode_*/decomp*/manifest.json'):
        manifest = json.loads(path.read_text())
        if manifest.get('context', {}).get('APP_NAME') == app:
            recorded.add(manifest['context']['EXECUTABLE_SHA256'])
    for campaign in root.glob(app + '_hip_*'):
        for path in campaign.glob('mode_*/**/config.txt'):
            fields = metadata(path)
            if (fields.get('APP_NAME') == app and fields.get('EXECUTABLE_SHA256')
                    and fields.get('COMMIT_STATUS') == 'COMMITTED'):
                recorded.add(fields['EXECUTABLE_SHA256'])
    if len(recorded) > 1:
        raise ValueError('Campaign contains tuning results from different executables for ' + app)
    expected = next(iter(recorded)) if recorded else None
    if expected is not None and not re.fullmatch('[0-9a-f]{64}', expected):
        raise ValueError('Invalid saved executable SHA256 for ' + app)
    return expected


def resume_executable(root, app, app_dir, source_root, stamp, names):
    """Find the trained binary before any workspace, translator or compiler runs."""
    expected = recorded_executable_sha256(root, app)
    if expected is None:
        return None  # This application has not trained yet; use the build preflight.
    folder = root / '_decomposition_executables' / app / expected
    candidates = [*sorted(folder.glob('*'))]
    candidates.extend(root / ('_bin_' + stamp) / name for name in names)
    candidates.extend(app_dir / name for name in names)
    # Old isolated workspaces can contain the only surviving original binary.
    try:
        relative = app_dir.relative_to(source_root)
    except ValueError:
        relative = None
    if relative is not None:
        candidates.extend(build / relative / name
                          for build in sorted(root.glob('_ops_build_*')) for name in names)
    for candidate in dict.fromkeys(candidates):
        if candidate.is_file() and executable_digest(candidate) == expected:
            return pin_executable(root, app, candidate, app_dir, True)
    # Reuse the strict diagnostic; a new build cannot repair this missing identity.
    return pin_executable(root, app, folder / names[0], app_dir, True)


def pin_executable(root, app, executable, app_dir, resume):
    """Reuse the trained executable after relocation or lost execution permissions."""
    expected = recorded_executable_sha256(root, app)
    expected = expected or executable_digest(executable)
    pinned = root / '_decomposition_executables' / app / expected / executable.name
    candidates = [pinned, *sorted(pinned.parent.glob('*')), executable, app_dir / executable.name]
    try:
        relative = app_dir.relative_to(root)
    except ValueError:
        relative = None
    if relative is not None and relative.parts and relative.parts[0].startswith('_ops_build_'):
        suffix = Path(*relative.parts[1:]) / executable.name
        candidates.extend(build / suffix for build in sorted(root.glob('_ops_build_*')))
    for candidate in dict.fromkeys(candidates):
        # A transfer can remove +x without changing the executable. Check its
        # content first; only the verified campaign copy receives permissions.
        if not candidate.is_file() or executable_digest(candidate) != expected:
            continue
        if candidate != pinned or candidate.is_symlink():
            pinned.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=str(pinned.parent), delete=False) as handle:
                temporary = Path(handle.name)
            try:
                shutil.copy2(candidate, temporary)
                if executable_digest(temporary) != expected:
                    raise ValueError('Executable changed while saving: ' + str(candidate))
                temporary.chmod(stat.S_IMODE(temporary.stat().st_mode) | stat.S_IXUSR)
                temporary.replace(pinned)
            finally:
                if temporary.exists():
                    temporary.unlink()
        elif not os.access(str(pinned), os.X_OK):
            pinned.chmod(stat.S_IMODE(pinned.stat().st_mode) | stat.S_IXUSR)
        if not os.access(str(pinned), os.X_OK):
            raise ValueError('Verified campaign executable is not executable: ' + str(pinned))
        identity = root / '_decomposition_executables' / app / 'identity.json'
        if not identity.exists():
            atomic_json(identity, {'schema_version': 1, 'app': app, 'sha256': expected,
                                   'binary_name': pinned.name})
        print('[OPS] using preserved campaign executable: ' + str(pinned), file=sys.stderr)
        return pinned
    raise ValueError('Original tuning executable SHA256=' + expected + ' is unavailable for ' + app
                     + '. Transfer the preserved _decomposition_executables directory with this campaign. '
                     'Expected file: ' + str(pinned) + '. A newly compiled executable cannot replace '
                     'the trained executable unless its SHA256 matches. Saved blocks were not changed.')


def normalize_blocks(path):
    """Strip OPS footer and retain the best observed row per kernel in this run."""
    best = {}
    with path.open() as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or reader.fieldnames[:4] != ['kernel_id', 'bx', 'by', 'bz']:
            raise ValueError('Invalid OPS block CSV header: ' + str(path))
        for row in reader:
            kid = (row.get('kernel_id') or '').strip()
            if not kid or kid.startswith(('Autotune --', 'total of rows --', 'app name --',
                                          'default total time --', 'best total time --')):
                continue
            kernel = int(kid)
            block = tuple(int(row[a]) for a in ('bx', 'by', 'bz'))
            if kernel < 0 or min(block) <= 0 or block[0] * block[1] * block[2] > 1024:
                raise ValueError('Invalid block dimensions: ' + str(path))
            elapsed = float(row.get('best_time') or 1)
            if not math.isfinite(elapsed) or elapsed <= 0:
                raise ValueError('Invalid kernel time: ' + str(path))
            if kernel not in best or elapsed < best[kernel][0]:
                best[kernel] = (elapsed, block)
    if not best:
        raise ValueError('No kernel blocks: ' + str(path))
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(['kernel_id', 'bx', 'by', 'bz'])
    writer.writerows((kid, *best[kid][1]) for kid in sorted(best))
    return out.getvalue().encode()


def best_block_rows(path):
    """Return the best measured (time, block) tuple for every kernel."""
    best = {}
    with Path(path).open() as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or reader.fieldnames[:4] != ['kernel_id', 'bx', 'by', 'bz']:
            raise ValueError('Invalid OPS block CSV header: ' + str(path))
        for row in reader:
            kid = (row.get('kernel_id') or '').strip()
            if not kid or kid.startswith(('Autotune --', 'total of rows --', 'app name --',
                                          'default total time --', 'best total time --')):
                continue
            kernel = int(kid)
            block = tuple(int(row[a]) for a in ('bx', 'by', 'bz'))
            elapsed = float(row.get('best_time') or 1)
            if (kernel < 0 or min(block) <= 0 or block[0] * block[1] * block[2] > 1024
                    or not math.isfinite(elapsed) or elapsed <= 0):
                raise ValueError('Invalid OPS block row: ' + str(path))
            if kernel not in best or elapsed < best[kernel][0]:
                best[kernel] = (elapsed, block)
    if not best:
        raise ValueError('No kernel blocks: ' + str(path))
    return best


def shared_blocks(sample_paths):
    """Build one deterministic per-kernel catalog from representative ranks."""
    rows = {rank: best_block_rows(path) for rank, path in sample_paths.items()}
    kernel_sets = {tuple(sorted(value)) for value in rows.values()}
    if len(kernel_sets) != 1:
        raise ValueError('sample ranks produced different kernel sets')
    kernels = next(iter(kernel_sets))
    selected = {}
    disagreements = []
    for kernel in kernels:
        candidates = {}
        for rank, values in rows.items():
            elapsed, block = values[kernel]
            candidate = candidates.setdefault(block, {'count': 0, 'best_time': elapsed,
                                                       'source_rank': rank})
            candidate['count'] += 1
            if elapsed < candidate['best_time']:
                candidate.update(best_time=elapsed, source_rank=rank)
        winner_block, winner = min(
            candidates.items(),
            key=lambda item: (-item[1]['count'], item[1]['best_time'], item[0]))
        selected[kernel] = winner_block
        if len(candidates) > 1:
            disagreements.append({
                'kernel_id': kernel,
                'candidates': [
                    {'block': list(block), **details}
                    for block, details in sorted(candidates.items())
                ],
                'selected': list(winner_block),
                'selected_source_rank': winner['source_rank'],
            })
    out = io.StringIO()
    writer = csv.writer(out, lineterminator='\n')
    writer.writerow(['kernel_id', 'bx', 'by', 'bz'])
    writer.writerows((kernel, *selected[kernel]) for kernel in sorted(selected))
    return out.getvalue().encode(), disagreements


def context():
    names = ('APP_NAME', 'GRID_X', 'GRID_Y', 'GRID_Z', 'GRID_CONFIG',
             'DECOMPOSITION_MODE', 'ACTIVE_NUM_RANKS', 'shape', 'APP_ARGS',
             'GPU_ARCH', 'EXECUTABLE_SHA256')
    result = {name: os.environ[name] for name in names}
    if os.environ.get('SAMPLED_AUTOTUNE') == '1':
        result['SAMPLED_AUTOTUNE'] = 'YES'
        result['AUTOTUNE_SAMPLE_RANKS'] = os.environ.get('AUTOTUNE_SAMPLE_RANKS', '0 1')
    return result


def case_path(ctx):
    label = '{APP_NAME}_hip_{GRID_X}x{GRID_Y}x{GRID_Z}_{GRID_CONFIG}'.format(**ctx)
    return Path(label) / ('mode_' + ctx['DECOMPOSITION_MODE']) / ('decomp' + ctx['shape'])


def validate_catalog(folder, ctx, manifest_name='manifest.json'):
    manifest = json.loads((folder / manifest_name).read_text())
    schema = manifest.get('schema_version')
    if schema not in (1, 2) or manifest.get('context') != ctx:
        raise ValueError('Incompatible application/grid/decomposition/GPU/executable: ' + str(folder))
    expected = ({'blocks.csv'} if schema == 2 else
                {'rank_%d/blocks.csv' % rank for rank in range(int(ctx['ACTIVE_NUM_RANKS']))})
    if set(manifest.get('files', {})) != expected:
        raise ValueError('Incomplete block catalog: ' + str(folder))
    for name, checksum in manifest['files'].items():
        data = (folder / name).read_bytes()
        if digest(data) != checksum or normalize_blocks(folder / name) != data:
            raise ValueError('Invalid or changed rank blocks: ' + str(folder / name))
    unsigned = dict(manifest)
    set_id = unsigned.pop('set_id', None)
    if set_id != digest(json.dumps(unsigned, sort_keys=True).encode()):
        raise ValueError('Changed manifest: ' + str(folder))
    return manifest


def select_repetition(runs, ctx):
    candidates, rejected = [], []
    nranks = int(ctx['ACTIVE_NUM_RANKS'])
    for config in runs.glob('iter_*/autotune_on/config.txt'):
        try:
            fields = metadata(config)
            if not result_complete(config.parent):
                continue
            # Only current campaign runs with matching recorded executable/context qualify.
            for key in ('APP_NAME', 'GRID_X', 'GRID_Y', 'GRID_Z', 'GRID_CONFIG',
                        'DECOMPOSITION_MODE', 'APP_ARGS', 'GPU_ARCH', 'EXECUTABLE_SHA256'):
                if fields.get(key) != ctx[key]:
                    raise ValueError('incompatible ' + key)
            if fields.get('NUM_MPI_RANKS') != str(nranks):
                raise ValueError('rank count mismatch')
            if 'x'.join(fields['DECOMP_P' + a] for a in 'XYZ') != ctx['shape']:
                raise ValueError('decomposition mismatch')
            elapsed = float(fields['APP_WALL_TIME'])
            if not math.isfinite(elapsed) or elapsed <= 0:
                raise ValueError('missing valid application wall time')
            with (config.parent / 'mpi_rank_metrics.csv').open() as handle:
                metrics = list(csv.DictReader(handle))
            if (len(metrics) != nranks or {r['rank_id'] for r in metrics} != {str(r) for r in range(nranks)}
                    or any(r['rank_status'] != 'OK' for r in metrics)):
                raise ValueError('missing or failed rank metrics')
            blocks = {}
            selection_details = {}
            if ctx.get('SAMPLED_AUTOTUNE') == 'YES':
                sample_ranks = [int(value) for value in ctx['AUTOTUNE_SAMPLE_RANKS'].split()]
                if not sample_ranks or any(rank < 0 or rank >= nranks for rank in sample_ranks):
                    raise ValueError('invalid sampled autotune ranks')
                sources = {
                    rank: config.parent / ('rank_%d' % rank) /
                    'autotune_on/ops_blocksize_best_logmod.csv'
                    for rank in sample_ranks
                }
                shared, disagreements = shared_blocks(sources)
                blocks['blocks.csv'] = shared
                selection_details = {
                    'sample_ranks': sample_ranks,
                    'sample_count': len(sample_ranks),
                    'disagreement_count': len(disagreements),
                    'disagreements': disagreements,
                }
            else:
                for rank in range(nranks):
                    source = config.parent / ('rank_%d' % rank) / 'autotune_on/ops_blocksize_best_logmod.csv'
                    blocks['rank_%d/blocks.csv' % rank] = normalize_blocks(source)
            candidates.append((elapsed, int(fields['RUN_ITERATION']), config,
                               blocks, selection_details))
        except (ValueError, KeyError, OSError) as exc:
            rejected.append(str(config) + ': ' + str(exc))
    if not candidates:
        raise ValueError('No complete compatible tuning repetition for ' + str(runs) + '\n' + '\n'.join(rejected))
    elapsed, repetition, config, blocks, selection_details = min(
        candidates, key=lambda item: item[:2])
    schema = 2 if ctx.get('SAMPLED_AUTOTUNE') == 'YES' else 1
    manifest = dict(schema_version=schema, context=ctx,
                    selection=('shared sampled-rank consensus' if schema == 2 else
                               'minimum APP_WALL_TIME among valid complete repetitions'),
                    source_run=str(config.parent.resolve()), repetition=repetition, app_wall_time_s=elapsed,
                    files={name: digest(data) for name, data in blocks.items()})
    if selection_details:
        manifest['sampled_selection'] = selection_details
    manifest['set_id'] = digest(json.dumps(manifest, sort_keys=True).encode())
    return manifest, blocks


def prepare(local_root, source_root, runs, ctx, train=False, check=False):
    relative = case_path(ctx)
    target = local_root / relative
    if target.exists():
        return target, validate_catalog(target, ctx)
    source = source_root / relative if source_root else target
    if not train and (source_root or source.exists()):
        manifest = validate_catalog(source, ctx)
        if check:
            return source, manifest
        blocks = {name: (source / name).read_bytes() for name in manifest['files']}
    else:
        manifest, blocks = select_repetition(runs, ctx)
        if check:
            return target, manifest
    target.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.blocks-', dir=str(target.parent)))
    try:
        for name, data in blocks.items():
            destination = stage / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        (stage / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        validate_catalog(stage, ctx)
        stage.rename(target)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    return target, manifest


def main():
    env = os.environ
    action = sys.argv[1]
    if action == 'audit':
        root = Path(sys.argv[2])
        committed, total = campaign_progress(root)
        records = [json.loads(line) for line in (root / 'plan.jsonl').read_text().splitlines() if line.strip()]
        pending = [r for r in records if not result_complete(root / r['target'], r)]
        executables = {}
        for app in sorted({r['app'] for r in records}):
            expected = recorded_executable_sha256(root, app)
            found = None
            if expected:
                folder = root / '_decomposition_executables' / app / expected
                found = next((str(p) for p in folder.glob('*') if p.is_file()
                              and executable_digest(p) == expected), None)
            executables[app] = dict(sha256=expected, preserved_binary=found,
                                   needs_initial_build=expected is None)
        print(json.dumps(dict(committed=committed, total=total, pending=len(pending),
                              pending_by_app={app: sum(r['app'] == app for r in pending)
                                              for app in executables},
                              next_case=pending[0]['case_id'] if pending else None,
                              executables=executables), indent=2))
        return
    if action == 'driver-status':
        root = Path(sys.argv[2])
        if sys.argv[3] == 'COMPLETE':
            done, total = campaign_progress(root)
            if done != total:
                raise ValueError('Cannot declare COMPLETE: unvalidated plan entries remain')
            if env.get('RUN_CLASS') == 'SMOKE':
                records = [json.loads(line) for line in (root / 'plan.jsonl').read_text().splitlines() if line.strip()]
                atomic_json(root / 'qualification_report.json', dict(
                    schema_version=1, status='PASS', run_class='SMOKE', scientific_result=False,
                    case_count=total, qualification_level=env.get('QUALIFICATION_LEVEL', ''),
                    apps=sorted({r['app'] for r in records}), nodes=sorted({r['nodes'] for r in records})))
        value = dict(executor_version=EXECUTOR_VERSION, status=sys.argv[3], reason=sys.argv[4],
                     job_id=os.environ.get('SLURM_JOB_ID', 'direct'),
                     generation=os.environ.get('OPS_EXECUTION_GENERATION', 'direct'))
        atomic_json(root / 'slurm' / 'driver_status.json', value)
        # Preserve individual job outcomes even when a successor replaces the current status.
        job = re.sub('[^A-Za-z0-9_.-]', '_', value['job_id'])
        atomic_json(root / 'slurm' / ('outcome_' + job + '.json'), value)
        if value['status'] == 'SUBMISSION_FAILED':
            atomic_json(root / 'slurm' / ('submission_failure_' + job + '.json'), value)
        return
    if action == 'driver-ready':
        path = Path(sys.argv[2]) / 'slurm' / 'driver_status.json'
        if path.exists():
            value = json.loads(path.read_text())
            if (value.get('executor_version') == EXECUTOR_VERSION and value.get('status') == 'BLOCKED'
                    and value.get('generation') == os.environ.get('OPS_EXECUTION_GENERATION', 'direct')
                    and os.environ.get('OPS_RETRY_BLOCKED') != '1'):
                sys.exit('ERROR: campaign BLOCKED: ' + value.get('reason', '')
                         + '; fix the cause before explicitly setting OPS_RETRY_BLOCKED=1')
        return
    if action == 'failed-attempts':
        count = 0
        for path in Path(sys.argv[2]).glob('attempt_*/config.txt'):
            fields = metadata(path)
            # Interrupted attempts remain recoverable and are never overwritten.
            if (fields.get('RUN_STATUS') == 'FAILED' and fields.get('INTERRUPTED') != 'YES'
                    and fields.get('PROCESS_EXIT_CODE', fields.get('RUN_EXIT_CODE')) not in ('130', '137', '138', '143')):
                count += 1
        print(count)
        return
    if action == 'complete':
        run = Path(sys.argv[2])
        root = Path(sys.argv[3]) if len(sys.argv) > 3 else None
        record = None
        if root and (root / 'plan.jsonl').exists():
            record = next((json.loads(line) for line in (root / 'plan.jsonl').read_text().splitlines()
                           if line.strip() and root / json.loads(line)['target'] == run), None)
            if record is None:
                sys.exit(1)
        sys.exit(0 if result_complete(run, record) else 1)
    if action == 'app-complete':
        root = Path(sys.argv[2])
        if not (root / 'plan.jsonl').exists():
            sys.exit(1)
        done, total = campaign_progress(root, sys.argv[3])
        sys.exit(0 if total > 0 and done == total else 1)
    if action == 'estimate':
        values = []
        for path in Path(sys.argv[2]).glob(sys.argv[3] + '_hip_*/mode_*/**/' + sys.argv[4] + '/config.txt'):
            fields = metadata(path)
            compatible = all(fields.get(k) == env[k] for k in
                             ('GRID_X', 'GRID_Y', 'GRID_Z', 'APP_ARGS', 'GPU_ARCH', 'EXECUTABLE_SHA256')
                             if k in env)
            compatible = compatible and ('ACTIVE_NUM_RANKS' not in env or fields.get('NUM_MPI_RANKS') == env['ACTIVE_NUM_RANKS'])
            if compatible and result_complete(path.parent):
                values.append(float(fields['JOB_WALL_TIME']))
        print(math.ceil(max(values)) if values else 0)
        return
    if action == 'resume-executable':
        selected = resume_executable(Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]),
                                     Path(sys.argv[5]), sys.argv[6], sys.argv[7:])
        if selected is not None:
            print(selected)
        return
    if action == 'pin-executable':
        print(pin_executable(Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]),
                             Path(sys.argv[5]), sys.argv[6] == '1'))
        return
    ctx = context()
    if action == 'summarize':
        labels = {0: ('autotune_off', 'WALL_TIME_NO_AUTOTUNE'),
                  1: ('autotune_on', 'WALL_TIME_AUTOTUNE'),
                  2: ('autotune_precomputed', 'WALL_TIME_PRECOMPUTED')}
        modes = list(map(int, env['AUTOTUNE_MODES'].split()))
        for repetition in range(1, int(env['RUN_ITERATIONS']) + 1):
            iteration = Path(env['CASE_RUNS_DIR']) / ('iter_%d' % repetition)
            if not iteration.is_dir():
                continue
            config = iteration / 'config.txt'
            fields = metadata(config) if config.exists() else {}
            for _, wall_key in labels.values():
                fields.pop(wall_key, None)
                fields.pop('JOB_' + wall_key, None)
            fields.update(AUTOTUNE_MODES=env['AUTOTUNE_MODES'], RUN_ITERATION=str(repetition))
            for mode in modes:
                label, wall_key = labels[mode]
                variant = iteration / label / 'config.txt'
                result = metadata(variant) if variant.exists() else (fields if mode == 0 else {})
                valid = result_complete(variant.parent)
                fields[wall_key] = result.get('APP_WALL_TIME', 'NA') if valid else 'NA'
                fields['JOB_' + wall_key] = result.get('JOB_WALL_TIME', 'NA') if valid else 'NA'
            temporary = config.with_suffix('.tmp')
            temporary.write_text(''.join('%s=%s\n' % item for item in fields.items()))
            temporary.replace(config)
        return
    if action == 'verify-run':
        run = Path(env['OPS_RUN_LOGS_DIR'])
        shared = run / 'blocks.csv'
        for rank in range(int(ctx['ACTIVE_NUM_RANKS'])):
            blocks = shared if shared.is_file() else run / ('rank_%d/blocks.csv' % rank)
            count = len(normalize_blocks(blocks).decode().splitlines()) - 1
            log = (run / ('ranks/rank_%d.log' % rank)).read_text(errors='replace')
            loaded = re.findall(r'Loaded (\d+) precomputed block sizes from ([^\r\n]+)', log)
            if not any(int(n) == count and name == str(blocks) for n, name in loaded):
                raise ValueError('rank %d did not confirm loading its %d saved blocks' % (rank, count))
        return
    source = Path(env['PRECOMPUTED_SOURCE']) if env.get('PRECOMPUTED_SOURCE') else None
    target, manifest = prepare(Path(env['PRECOMPUTED_ROOT']), source,
                               Path(env['CASE_RUNS_DIR']), ctx,
                               train=action == 'train', check=action == 'check')
    print('[OPS] frozen blocks %s: %s' % (manifest['set_id'], target))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError) as exc:
        sys.exit('ERROR: precomputed blocks: ' + str(exc))
